# Webster-2022

## Complaint Box

### Team Name : [0π](https://github.com/Kitashi14/Webster-2022)

### Team Members Name :

- Sudhir Shukla
- Rishav Raj
- Ritik Vaidyasen
- Amit Kumar Singh

### Proposed Features :

- User Login/ Signup
- Various user profiles (residents, electrician etc)
- One can add multiple profession
- Standard & Custom Complaints
- Add/Delete/Update complaints
- Worker of different profession can select the complaint the want to take
- Ratings on complaints by the resolve work done on them

### Tech Stack :

1. NODE js
2. Tailwind
3. HTML
4. CSS
5. JavaScript
6. MongoDB
7. ReactJS
8. ExpressJS

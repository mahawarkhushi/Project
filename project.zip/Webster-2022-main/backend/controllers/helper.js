//functions to be used at various places

//for removing spaces at last and end
const removeSpaces = (data) => {
  //removing spaces at start
  var st = 0;
  for (var i = 0; i < data.length; i++) {
    if (data[i] === " ") st++;
    else break;
  }
  //removing spaces from last
  var end = data.length - 1;
  for (var i = end; i >= 0; i--) {
    if (data[i] === " ") end--;
    else break;
  }
  let updatedData = "";
  for (var i = st; i <= end; i++) {
    updatedData = updatedData + data[i];
  }

  return updatedData;
};

const professions = [
  {
      id:"1",
      name:"Professor",
      logo:"https://www.nicepng.com/png/detail/129-1290978_teacher-teacher-icon-png.png"
  },
  {
      id:"12",
      name:"Doctor",
      logo:"https://www.nicepng.com/png/detail/131-1318685_health-icon-png-health-care-icon-png.png"
  },
  
  {
      id:"11",
      name:"Electrician",
      logo:"https://www.nicepng.com/png/detail/251-2517048_electrician-clipart-fridge-repair-washing-machine-parts-icon.png"
  },
  {
      id:"13",
      name:"Accountant",
      logo:"https://www.nicepng.com/png/detail/257-2579139_create-an-account-with-acudeen-technologies-create-account.png"
  },
  {
      id:"14",
      name:"Gardener",
      logo:"https://www.nicepng.com/png/detail/204-2049005_graphic-stock-watering-tool-for-gardening-png-icon.png"
  },
  {
      id:"15",
      name:"Librarian",
      logo:"https://png.pngtree.com/element_our/20190528/ourlarge/pngtree-library-icon-image_1144615.jpg"
  },
  {
      id:"16",
      name:"Tailor",
      logo:"https://cdn-icons-png.flaticon.com/512/1995/1995535.png"
  },
  {
      id:"17",
      name:"Washerman",
      logo:"LocalLaundryServiceIcon"
  },
  {
      id:"18",
      name:"Plumber",
      logo:"https://i.pinimg.com/originals/04/b6/7b/04b67b34060a5704eb3edad0d294e914.png"
  },
  {
      id:"19",
      name:"Bus Driver",
      logo: "DirectionsBus"
  }
];

exports.removeSpaces= removeSpaces;
exports.professions = professions;